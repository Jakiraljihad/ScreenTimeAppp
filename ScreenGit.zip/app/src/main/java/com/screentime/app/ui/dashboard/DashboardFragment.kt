package com.screentime.app.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.color.MaterialColors
import com.screentime.app.R
import com.screentime.app.adapters.TopAppAdapter
import com.screentime.app.databinding.FragmentDashboardBinding
import com.screentime.app.services.UsageStatsHelper
import com.screentime.app.utils.AdviceEngine

/**
 * Dashboard Fragment — shows total screen time, top apps, weekly chart, advice
 * File: app/src/main/java/com/screentime/app/ui/dashboard/DashboardFragment.kt
 */
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private val viewModel: DashboardViewModel by viewModels()
    private lateinit var topAppAdapter: TopAppAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupChart()
        observeViewModel()
        setupRefresh()
        setupPermissionBanner()
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshData()
    }

    private fun setupRecyclerView() {
        topAppAdapter = TopAppAdapter()
        binding.rvTopApps.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = topAppAdapter
            isNestedScrollingEnabled = false
        }
    }

    private fun observeViewModel() {
        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
            binding.contentLayout.visibility = if (loading) View.GONE else View.VISIBLE
        }

        viewModel.hasPermission.observe(viewLifecycleOwner) { hasPermission ->
            binding.permissionBanner.visibility = if (hasPermission) View.GONE else View.VISIBLE
        }

        viewModel.totalScreenTimeMs.observe(viewLifecycleOwner) { totalMs ->
            updateScreenTimeDisplay(totalMs)
        }

        viewModel.topApps.observe(viewLifecycleOwner) { apps ->
            topAppAdapter.submitList(apps)
            binding.tvNoApps.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.advice.observe(viewLifecycleOwner) { advice ->
            updateAdviceCard(advice)
        }

        viewModel.weeklyData.observe(viewLifecycleOwner) { weeklyData ->
            if (weeklyData.isNotEmpty()) {
                updateWeeklyChart(weeklyData)
            }
        }
    }

    private fun updateScreenTimeDisplay(totalMs: Long) {
        val hours = totalMs / 3_600_000L
        val minutes = (totalMs % 3_600_000L) / 60_000L

        binding.tvHours.text = hours.toString()
        binding.tvMinutes.text = String.format("%02d", minutes)
        binding.tvScreenTimeLabel.text = "hours  minutes"

        // Animate the number
        val fadeIn = AnimationUtils.loadAnimation(requireContext(), R.anim.fade_in_up)
        binding.tvHours.startAnimation(fadeIn)
        binding.tvMinutes.startAnimation(fadeIn)

        // Update daily progress
        val dailyGoalMs = 3 * 3_600_000L // 3 hour default goal
        val progress = ((totalMs.toFloat() / dailyGoalMs.toFloat()) * 100).toInt().coerceIn(0, 100)
        binding.dailyGoalProgress.progress = progress
        binding.tvGoalProgress.text = "$progress% of daily goal"
    }

    private fun updateAdviceCard(advice: AdviceEngine.Advice) {
        binding.adviceEmoji.text = advice.emoji
        binding.adviceTitle.text = advice.title
        binding.adviceMessage.text = advice.message
        binding.adviceTip.text = advice.tip

        // Set card color based on level
        val colorRes = when (advice.level) {
            AdviceEngine.UsageLevel.EXCELLENT, AdviceEngine.UsageLevel.GOOD ->
                com.google.android.material.R.attr.colorSecondaryContainer
            AdviceEngine.UsageLevel.MODERATE ->
                com.google.android.material.R.attr.colorSurfaceVariant
            AdviceEngine.UsageLevel.HIGH, AdviceEngine.UsageLevel.EXCESSIVE ->
                com.google.android.material.R.attr.colorErrorContainer
        }
        val color = MaterialColors.getColor(binding.root, colorRes)
        binding.adviceCard.setCardBackgroundColor(color)
    }

    private fun setupChart() {
        binding.weeklyChart.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setDrawGridBackground(false)
            setDrawBarShadow(false)
            setFitBars(true)
            isHighlightPerTapEnabled = false
            animateY(1000)

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                granularity = 1f
                textColor = MaterialColors.getColor(binding.root,
                    com.google.android.material.R.attr.colorOnSurface)
            }

            axisLeft.apply {
                setDrawGridLines(true)
                axisMinimum = 0f
                textColor = MaterialColors.getColor(binding.root,
                    com.google.android.material.R.attr.colorOnSurface)
            }

            axisRight.isEnabled = false
        }
    }

    private fun updateWeeklyChart(weeklyData: Map<String, Long>) {
        val labels = weeklyData.keys.toList()
        val entries = weeklyData.values.mapIndexed { index, ms ->
            BarEntry(index.toFloat(), ms / 3_600_000f) // convert to hours
        }

        val primaryColor = MaterialColors.getColor(
            binding.root,
            com.google.android.material.R.attr.colorPrimary
        )

        val dataSet = BarDataSet(entries, "Hours").apply {
            color = primaryColor
            setDrawValues(true)
            valueTextSize = 9f
        }

        binding.weeklyChart.apply {
            data = BarData(dataSet)
            xAxis.valueFormatter = IndexAxisValueFormatter(labels)
            invalidate()
        }
    }

    private fun setupRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.refreshData()
            binding.swipeRefresh.isRefreshing = false
        }
    }

    private fun setupPermissionBanner() {
        binding.btnGrantPermission.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
