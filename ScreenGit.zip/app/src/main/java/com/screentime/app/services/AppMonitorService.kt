package com.screentime.app.services

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.screentime.app.R
import com.screentime.app.ScreenTimeApplication
import com.screentime.app.activities.MainActivity
import com.screentime.app.data.models.UsageRecord
import com.screentime.app.utils.PrefsManager
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * Foreground service that periodically syncs usage stats to local DB
 * File: app/src/main/java/com/screentime/app/services/AppMonitorService.kt
 *
 * Runs every 5 minutes to update usage records.
 * This ensures data is available even if user doesn't open the app.
 */
class AppMonitorService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var monitorJob: Job? = null

    private val SYNC_INTERVAL_MS = 5 * 60 * 1000L // 5 minutes

    override fun onCreate() {
        super.onCreate()
        startForeground(
            ScreenTimeApplication.NOTIFICATION_ID_MONITOR,
            buildNotification()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startMonitoring()
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY // restart if killed
    }

    override fun onBind(intent: IBinder?): IBinder? = null

    /**
     * Start periodic sync loop
     */
    private fun startMonitoring() {
        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            while (isActive) {
                syncUsageStats()
                sendLimitWarnings()
                delay(SYNC_INTERVAL_MS)
            }
        }
    }

    /**
     * Read from UsageStatsManager and save to Room DB
     */
    private suspend fun syncUsageStats() {
        val app = applicationContext as ScreenTimeApplication
        val usageHelper = UsageStatsHelper(applicationContext)

        if (!usageHelper.hasUsageStatsPermission()) return

        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val todayUsage = usageHelper.getTodayUsage()

        val records = todayUsage.map { usageInfo ->
            UsageRecord(
                packageName = usageInfo.packageName,
                appName = usageInfo.appName,
                usageTimeMs = usageInfo.usageTimeMs,
                date = today
            )
        }

        if (records.isNotEmpty()) {
            app.usageRecordRepository.insertAll(records)
        }

        // Clean old data (keep 30 days)
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_MONTH, -30)
        val cutoff = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)
        app.usageRecordRepository.deleteOldRecords(cutoff)
    }

    /**
     * Check if any app is approaching its limit and send notification
     */
    private suspend fun sendLimitWarnings() {
        val app = applicationContext as ScreenTimeApplication
        val usageHelper = UsageStatsHelper(applicationContext)
        val prefs = PrefsManager(applicationContext)

        val limits = app.appLimitRepository.getAllLimitsSync()
        val todayUsage = usageHelper.getTodayUsage()

        for (limit in limits) {
            if (!limit.isEnabled || limit.isBlocked) continue

            val usage = todayUsage.find { it.packageName == limit.packageName } ?: continue
            val usageMinutes = usage.usageMinutes
            val limitMinutes = limit.limitMinutes

            // Warn at 80% of limit
            val warningThreshold = (limitMinutes * 0.8).toLong()
            if (usageMinutes >= warningThreshold && usageMinutes < limitMinutes) {
                val lastWarnKey = "last_warn_${limit.packageName}"
                val lastWarn = prefs.getLong(lastWarnKey, 0L)
                val now = System.currentTimeMillis()

                // Only warn once per hour
                if (now - lastWarn > 3_600_000L) {
                    prefs.putLong(lastWarnKey, now)
                    sendWarningNotification(
                        limit.appName,
                        usageMinutes,
                        limitMinutes
                    )
                }
            }
        }
    }

    /**
     * Send high-priority notification when approaching limit
     */
    private fun sendWarningNotification(appName: String, usageMin: Long, limitMin: Int) {
        val remaining = limitMin - usageMin
        val builder = NotificationCompat.Builder(this, ScreenTimeApplication.CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentTitle("⚠️ Usage Limit Warning")
            .setContentText("$appName — only ${remaining}m of limit remaining")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        val notificationManager = getSystemService(android.app.NotificationManager::class.java)
        notificationManager.notify(appName.hashCode(), builder.build())
    }

    /**
     * Build persistent foreground notification
     */
    private fun buildNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, ScreenTimeApplication.CHANNEL_MONITOR)
            .setContentTitle("Screen Time Active")
            .setContentText("Monitoring your app usage")
            .setSmallIcon(R.drawable.ic_timer)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        monitorJob?.cancel()
        serviceScope.cancel()
    }

    companion object {
        const val ACTION_START = "action_start_monitor"
        const val ACTION_STOP = "action_stop_monitor"
    }
}
