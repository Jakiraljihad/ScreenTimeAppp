package com.screentime.app.activities

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.screentime.app.R
import com.screentime.app.adapters.OnboardingAdapter
import com.screentime.app.databinding.ActivityOnboardingBinding
import com.screentime.app.utils.PrefsManager

/**
 * Onboarding flow — shown on first launch
 * Guides user to grant Usage Stats and Accessibility permissions
 * File: app/src/main/java/com/screentime/app/activities/OnboardingActivity.kt
 */
class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding
    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = PrefsManager(this)

        setupViewPager()
        setupButtons()
    }

    private fun setupViewPager() {
        val pages = listOf(
            OnboardingAdapter.OnboardingPage(
                emoji = "📱",
                title = "Track Your Screen Time",
                description = "See exactly how much time you spend on each app every day."
            ),
            OnboardingAdapter.OnboardingPage(
                emoji = "🚫",
                title = "Set App Limits",
                description = "Set daily time limits for distracting apps. We'll block them when you hit the limit."
            ),
            OnboardingAdapter.OnboardingPage(
                emoji = "🎯",
                title = "Focus Mode",
                description = "Start a focus session to block distractions and stay productive."
            ),
            OnboardingAdapter.OnboardingPage(
                emoji = "🔐",
                title = "Grant Permissions",
                description = "We need Usage Access and Accessibility permissions to track and block apps."
            )
        )

        binding.viewPager.adapter = OnboardingAdapter(pages)
        binding.pageIndicator.setViewPager(binding.viewPager)

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateButtonState(position, pages.size)
            }
        })
    }

    private fun setupButtons() {
        binding.btnNext.setOnClickListener {
            val current = binding.viewPager.currentItem
            val total = binding.viewPager.adapter?.itemCount ?: 1

            if (current < total - 1) {
                binding.viewPager.currentItem = current + 1
            } else {
                requestPermissionsAndFinish()
            }
        }

        binding.btnSkip.setOnClickListener {
            completeOnboarding()
        }
    }

    private fun updateButtonState(position: Int, total: Int) {
        if (position == total - 1) {
            binding.btnNext.text = "Grant Permissions"
            binding.btnSkip.text = "Skip for Now"
        } else {
            binding.btnNext.text = "Next"
            binding.btnSkip.text = "Skip"
        }
    }

    private fun requestPermissionsAndFinish() {
        // Open Usage Access Settings
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        completeOnboarding()
    }

    private fun completeOnboarding() {
        prefs.setOnboardingComplete(true)
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
