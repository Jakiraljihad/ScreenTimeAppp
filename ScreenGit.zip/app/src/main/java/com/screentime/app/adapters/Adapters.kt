package com.screentime.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.screentime.app.R
import com.screentime.app.data.models.AppUsageInfo
import com.screentime.app.databinding.ItemAppUsageBinding
import com.screentime.app.databinding.ItemTopAppBinding
import com.screentime.app.databinding.ItemFocusAppBinding
import com.screentime.app.databinding.ItemOnboardingPageBinding

// ===== TOP APP ADAPTER (Dashboard) =====

/**
 * Adapter for top 5 apps on Dashboard
 * File: app/src/main/java/com/screentime/app/adapters/TopAppAdapter.kt
 */
class TopAppAdapter : ListAdapter<AppUsageInfo, TopAppAdapter.ViewHolder>(DIFF) {

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<AppUsageInfo>() {
            override fun areItemsTheSame(a: AppUsageInfo, b: AppUsageInfo) =
                a.packageName == b.packageName
            override fun areContentsTheSame(a: AppUsageInfo, b: AppUsageInfo) =
                a.usageTimeMs == b.usageTimeMs
        }
    }

    inner class ViewHolder(val binding: ItemTopAppBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemTopAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = getItem(position)
        with(holder.binding) {
            tvAppName.text = app.appName
            tvUsageTime.text = app.getFormattedTime()
            tvRank.text = "#${position + 1}"

            // Set app icon
            if (app.iconDrawable != null) {
                ivAppIcon.setImageDrawable(app.iconDrawable)
            } else {
                ivAppIcon.setImageResource(R.drawable.ic_app_default)
            }

            // Usage bar
            usageBar.progress = app.limitProgress.coerceIn(0, 100)
            if (app.isOverLimit) {
                usageBar.setIndicatorColor(
                    root.context.getColor(R.color.red_warning)
                )
                tvLimitStatus.visibility = View.VISIBLE
                tvLimitStatus.text = "Limit reached"
            } else {
                tvLimitStatus.visibility = View.GONE
            }
        }
    }
}

// ===== APP USAGE ADAPTER (App Usage screen) =====

/**
 * Adapter for full app list on App Usage screen
 * File: app/src/main/java/com/screentime/app/adapters/AppUsageAdapter.kt
 */
class AppUsageAdapter(
    private val onSetLimit: (AppUsageInfo) -> Unit,
    private val onRemoveLimit: (AppUsageInfo) -> Unit
) : ListAdapter<AppUsageInfo, AppUsageAdapter.ViewHolder>(DIFF) {

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<AppUsageInfo>() {
            override fun areItemsTheSame(a: AppUsageInfo, b: AppUsageInfo) =
                a.packageName == b.packageName
            override fun areContentsTheSame(a: AppUsageInfo, b: AppUsageInfo) =
                a == b
        }
    }

    inner class ViewHolder(val binding: ItemAppUsageBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemAppUsageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = getItem(position)
        with(holder.binding) {
            tvAppName.text = app.appName
            tvUsageTime.text = app.getFormattedTime()

            if (app.iconDrawable != null) {
                ivAppIcon.setImageDrawable(app.iconDrawable)
            } else {
                ivAppIcon.setImageResource(R.drawable.ic_app_default)
            }

            // Limit status chip
            if (app.isBlocked) {
                chipLimit.visibility = View.VISIBLE
                chipLimit.text = "🚫 Blocked"
                chipLimit.setChipBackgroundColorResource(R.color.red_warning_light)
            } else if (app.hasLimit) {
                chipLimit.visibility = View.VISIBLE
                chipLimit.text = "⏱ ${app.limitMinutes}m limit"
                val colorRes = if (app.isOverLimit) R.color.red_warning_light else R.color.blue_primary_light
                chipLimit.setChipBackgroundColorResource(colorRes)
            } else {
                chipLimit.visibility = View.GONE
            }

            // Progress bar
            if (app.hasLimit) {
                limitProgress.visibility = View.VISIBLE
                limitProgress.progress = app.limitProgress
                val color = if (app.isOverLimit)
                    root.context.getColor(R.color.red_warning)
                else
                    root.context.getColor(R.color.blue_primary)
                limitProgress.setIndicatorColor(color)
            } else {
                limitProgress.visibility = View.GONE
            }

            // Set limit button
            btnSetLimit.setOnClickListener { onSetLimit(app) }
        }
    }
}

// ===== FOCUS APP ADAPTER =====

/**
 * Adapter for selecting apps to block during Focus Mode
 * File: app/src/main/java/com/screentime/app/adapters/FocusAppAdapter.kt
 */
class FocusAppAdapter(
    private val onToggle: (String) -> Unit
) : ListAdapter<AppUsageInfo, FocusAppAdapter.ViewHolder>(DIFF) {

    private var selectedApps = setOf<String>()

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<AppUsageInfo>() {
            override fun areItemsTheSame(a: AppUsageInfo, b: AppUsageInfo) =
                a.packageName == b.packageName
            override fun areContentsTheSame(a: AppUsageInfo, b: AppUsageInfo) =
                a.packageName == b.packageName
        }
    }

    fun setSelectedApps(apps: Set<String>) {
        selectedApps = apps
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: ItemFocusAppBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemFocusAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = getItem(position)
        with(holder.binding) {
            tvAppName.text = app.appName
            tvUsageTime.text = app.getFormattedTime()
            if (app.iconDrawable != null) ivAppIcon.setImageDrawable(app.iconDrawable)
            else ivAppIcon.setImageResource(R.drawable.ic_app_default)

            checkBox.isChecked = selectedApps.contains(app.packageName)
            checkBox.setOnCheckedChangeListener(null)
            checkBox.setOnCheckedChangeListener { _, _ -> onToggle(app.packageName) }

            root.setOnClickListener { onToggle(app.packageName) }
        }
    }
}

// ===== ONBOARDING ADAPTER =====

/**
 * ViewPager adapter for onboarding pages
 * File: app/src/main/java/com/screentime/app/adapters/OnboardingAdapter.kt
 */
class OnboardingAdapter(
    private val pages: List<OnboardingPage>
) : RecyclerView.Adapter<OnboardingAdapter.ViewHolder>() {

    data class OnboardingPage(
        val emoji: String,
        val title: String,
        val description: String
    )

    inner class ViewHolder(val binding: ItemOnboardingPageBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
        ItemOnboardingPageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val page = pages[position]
        holder.binding.tvEmoji.text = page.emoji
        holder.binding.tvTitle.text = page.title
        holder.binding.tvDescription.text = page.description
    }

    override fun getItemCount() = pages.size
}
