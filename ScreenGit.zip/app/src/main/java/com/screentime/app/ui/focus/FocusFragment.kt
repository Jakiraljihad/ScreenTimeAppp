package com.screentime.app.ui.focus

import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.screentime.app.R
import com.screentime.app.ScreenTimeApplication
import com.screentime.app.adapters.FocusAppAdapter
import com.screentime.app.data.models.AppUsageInfo
import com.screentime.app.data.models.FocusSession
import com.screentime.app.databinding.FragmentFocusBinding
import com.screentime.app.services.UsageStatsHelper
import com.screentime.app.utils.PrefsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

// ===== VIEW MODEL =====

class FocusViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = PrefsManager(application)
    private val usageHelper = UsageStatsHelper(application)
    private val app = application as ScreenTimeApplication

    val isFocusActive = MutableLiveData<Boolean>(prefs.isFocusModeActive())
    val focusEndTime = MutableLiveData<Long>(prefs.getFocusEndTime())
    val selectedDurationMinutes = MutableLiveData<Int>(25)
    val installedApps = MutableLiveData<List<AppUsageInfo>>(emptyList())
    val selectedAppsToBlock = MutableLiveData<Set<String>>(prefs.getFocusBlockedApps())
    val completedSessionsToday = MutableLiveData<Int>(0)

    init {
        loadInstalledApps()
        loadCompletedSessions()
    }

    private fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = usageHelper.getTodayUsage().take(20)
            withContext(Dispatchers.Main) {
                installedApps.value = apps
            }
        }
    }

    private fun loadCompletedSessions() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        app.database.focusSessionDao()
            .getCompletedSessionsForDate(today)
            .observeForever { count ->
                completedSessionsToday.value = count
            }
    }

    fun startFocus(durationMinutes: Int) {
        val endTime = System.currentTimeMillis() + durationMinutes * 60_000L
        prefs.setFocusModeActive(true)
        prefs.setFocusEndTime(endTime)
        prefs.setFocusDurationMinutes(durationMinutes)
        prefs.setFocusBlockedApps(selectedAppsToBlock.value ?: emptySet())

        isFocusActive.value = true
        focusEndTime.value = endTime

        // Save session to DB
        viewModelScope.launch(Dispatchers.IO) {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val session = FocusSession(
                durationMinutes = durationMinutes,
                startTime = System.currentTimeMillis(),
                date = today
            )
            app.database.focusSessionDao().insert(session)
        }
    }

    fun stopFocus() {
        prefs.setFocusModeActive(false)
        prefs.setFocusEndTime(0L)
        isFocusActive.value = false
        focusEndTime.value = 0L
    }

    fun completeFocus() {
        viewModelScope.launch(Dispatchers.IO) {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val session = app.database.focusSessionDao().getActiveSession()
            session?.let {
                app.database.focusSessionDao().update(
                    it.copy(endTime = System.currentTimeMillis(), isCompleted = true)
                )
            }
            withContext(Dispatchers.Main) { stopFocus() }
        }
    }

    fun toggleAppBlock(packageName: String) {
        val current = selectedAppsToBlock.value?.toMutableSet() ?: mutableSetOf()
        if (current.contains(packageName)) current.remove(packageName) else current.add(packageName)
        selectedAppsToBlock.value = current
    }
}

// ===== FRAGMENT =====

/**
 * Focus Mode Fragment — Pomodoro-style timer with app blocking
 * File: app/src/main/java/com/screentime/app/ui/focus/FocusFragment.kt
 */
class FocusFragment : Fragment() {

    private var _binding: FragmentFocusBinding? = null
    private val binding get() = _binding!!

    private val viewModel: FocusViewModel by viewModels()
    private var countDownTimer: CountDownTimer? = null
    private lateinit var focusAppAdapter: FocusAppAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFocusBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupDurationSelector()
        setupAppList()
        setupStartButton()
        observeViewModel()
    }

    private fun setupDurationSelector() {
        val durations = listOf(15, 25, 30, 45, 60)
        val chips = listOf(
            binding.chip15, binding.chip25, binding.chip30,
            binding.chip45, binding.chip60
        )

        chips.forEachIndexed { index, chip ->
            chip.text = "${durations[index]}m"
            chip.setOnClickListener {
                viewModel.selectedDurationMinutes.value = durations[index]
                chips.forEach { it.isChecked = false }
                chip.isChecked = true
            }
        }

        binding.chip25.isChecked = true // default 25 min
    }

    private fun setupAppList() {
        focusAppAdapter = FocusAppAdapter { packageName ->
            viewModel.toggleAppBlock(packageName)
        }
        binding.rvFocusApps.adapter = focusAppAdapter
    }

    private fun setupStartButton() {
        binding.btnStartFocus.setOnClickListener {
            val duration = viewModel.selectedDurationMinutes.value ?: 25
            viewModel.startFocus(duration)
        }

        binding.btnStopFocus.setOnClickListener {
            stopTimer()
            viewModel.stopFocus()
        }
    }

    private fun observeViewModel() {
        viewModel.isFocusActive.observe(viewLifecycleOwner) { active ->
            updateFocusUI(active)
        }

        viewModel.focusEndTime.observe(viewLifecycleOwner) { endTime ->
            if (endTime > 0 && viewModel.isFocusActive.value == true) {
                startCountdown(endTime)
            }
        }

        viewModel.installedApps.observe(viewLifecycleOwner) { apps ->
            focusAppAdapter.submitList(apps)
        }

        viewModel.selectedAppsToBlock.observe(viewLifecycleOwner) { selected ->
            focusAppAdapter.setSelectedApps(selected)
        }

        viewModel.completedSessionsToday.observe(viewLifecycleOwner) { count ->
            binding.tvSessionsToday.text = "$count sessions today"
        }
    }

    private fun updateFocusUI(active: Boolean) {
        if (active) {
            binding.setupLayout.visibility = View.GONE
            binding.activeLayout.visibility = View.VISIBLE
            val anim = AnimationUtils.loadAnimation(requireContext(), R.anim.fade_in_up)
            binding.activeLayout.startAnimation(anim)
        } else {
            binding.setupLayout.visibility = View.VISIBLE
            binding.activeLayout.visibility = View.GONE
            stopTimer()
        }
    }

    private fun startCountdown(endTime: Long) {
        countDownTimer?.cancel()
        val remaining = endTime - System.currentTimeMillis()
        if (remaining <= 0) {
            viewModel.completeFocus()
            return
        }

        countDownTimer = object : CountDownTimer(remaining, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val minutes = millisUntilFinished / 60_000L
                val seconds = (millisUntilFinished % 60_000L) / 1000L
                binding.tvTimer.text = String.format("%02d:%02d", minutes, seconds)

                val duration = (viewModel.selectedDurationMinutes.value ?: 25) * 60_000L
                val progress = ((1f - millisUntilFinished.toFloat() / duration) * 100).toInt()
                binding.timerProgress.progress = progress
            }

            override fun onFinish() {
                binding.tvTimer.text = "00:00"
                binding.timerProgress.progress = 100
                viewModel.completeFocus()
                showCompletionCelebration()
            }
        }.start()
    }

    private fun stopTimer() {
        countDownTimer?.cancel()
        binding.tvTimer.text = "00:00"
        binding.timerProgress.progress = 0
    }

    private fun showCompletionCelebration() {
        binding.celebrationLayout.visibility = View.VISIBLE
        val anim = AnimationUtils.loadAnimation(requireContext(), R.anim.fade_in_up)
        binding.celebrationLayout.startAnimation(anim)
        binding.celebrationLayout.postDelayed({
            binding.celebrationLayout.visibility = View.GONE
        }, 3000L)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        countDownTimer?.cancel()
        _binding = null
    }
}
