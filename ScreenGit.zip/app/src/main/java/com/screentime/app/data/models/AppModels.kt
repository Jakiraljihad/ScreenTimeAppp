package com.screentime.app.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity: Stores daily app usage records
 * File: app/src/main/java/com/screentime/app/data/models/UsageRecord.kt
 */
@Entity(tableName = "usage_records")
data class UsageRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packageName: String,      // e.g. "com.google.youtube"
    val appName: String,          // e.g. "YouTube"
    val usageTimeMs: Long,        // Usage time in milliseconds
    val date: String,             // Format: "yyyy-MM-dd"
    val lastUpdated: Long = System.currentTimeMillis()
)

/**
 * Entity: Stores app daily limits set by user
 * File: app/src/main/java/com/screentime/app/data/models/AppLimit.kt
 */
@Entity(tableName = "app_limits")
data class AppLimit(
    @PrimaryKey
    val packageName: String,
    val appName: String,
    val appIcon: String = "",         // Base64 or resource name
    val limitMinutes: Int,            // Daily limit in minutes
    val isBlocked: Boolean = false,   // Completely block (no time limit)
    val isEnabled: Boolean = true,    // Limit active toggle
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Entity: Focus mode session record
 * File: part of models package
 */
@Entity(tableName = "focus_sessions")
data class FocusSession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val durationMinutes: Int,
    val startTime: Long,
    val endTime: Long? = null,
    val isCompleted: Boolean = false,
    val date: String
)

/**
 * Data class for app usage displayed in UI (not an entity)
 */
data class AppUsageInfo(
    val packageName: String,
    val appName: String,
    val usageTimeMs: Long,
    val limitMinutes: Int = 0,        // 0 means no limit
    val isBlocked: Boolean = false,
    val iconDrawable: android.graphics.drawable.Drawable? = null
) {
    val usageMinutes: Long get() = usageTimeMs / 60_000L
    val usageHours: Long get() = usageMinutes / 60L
    val hasLimit: Boolean get() = limitMinutes > 0
    val isOverLimit: Boolean get() = hasLimit && usageMinutes >= limitMinutes
    val limitProgress: Int get() {
        if (limitMinutes <= 0) return 0
        return ((usageMinutes.toFloat() / limitMinutes.toFloat()) * 100).toInt().coerceIn(0, 100)
    }

    fun getFormattedTime(): String {
        val hours = usageTimeMs / 3_600_000L
        val minutes = (usageTimeMs % 3_600_000L) / 60_000L
        return when {
            hours > 0 -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m"
            else -> "< 1m"
        }
    }
}
