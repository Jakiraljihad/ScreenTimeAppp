package com.screentime.app.ui.settings

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.AndroidViewModel
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.screentime.app.ScreenTimeApplication
import com.screentime.app.databinding.FragmentSettingsBinding
import com.screentime.app.services.AppBlockAccessibilityService
import com.screentime.app.services.UsageStatsHelper
import com.screentime.app.utils.PrefsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import android.app.Application
import android.content.ComponentName
import android.provider.Settings.Secure

/**
 * Settings Fragment — app configuration, permissions, resets
 * File: app/src/main/java/com/screentime/app/ui/settings/SettingsFragment.kt
 */
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private lateinit var prefs: PrefsManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        prefs = PrefsManager(requireContext())

        setupPermissionSection()
        setupGoalSection()
        setupNotificationSection()
        setupResetSection()
        setupAboutSection()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun setupPermissionSection() {
        // Usage Stats
        binding.rowUsageAccess.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        // Accessibility Service
        binding.rowAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // Notification Permission
        binding.rowNotificationPermission.setOnClickListener {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
            }
        }
    }

    private fun updatePermissionStatus() {
        val usageHelper = UsageStatsHelper(requireContext())
        val hasUsage = usageHelper.hasUsageStatsPermission()
        val hasAccessibility = isAccessibilityEnabled()

        binding.statusUsageAccess.text = if (hasUsage) "✅ Granted" else "❌ Not Granted"
        binding.statusAccessibility.text = if (hasAccessibility) "✅ Enabled" else "❌ Not Enabled"
        binding.statusUsageAccess.setTextColor(
            resources.getColor(
                if (hasUsage) android.R.color.holo_green_dark
                else android.R.color.holo_red_dark,
                null
            )
        )
        binding.statusAccessibility.setTextColor(
            resources.getColor(
                if (hasAccessibility) android.R.color.holo_green_dark
                else android.R.color.holo_red_dark,
                null
            )
        )
    }

    private fun isAccessibilityEnabled(): Boolean {
        val service = "${requireContext().packageName}/${AppBlockAccessibilityService::class.java.canonicalName}"
        val enabled = Secure.getString(
            requireContext().contentResolver,
            Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains(service)
    }

    private fun setupGoalSection() {
        val currentGoal = prefs.getDailyGoalHours()
        binding.sliderDailyGoal.value = currentGoal.toFloat()
        binding.tvDailyGoalValue.text = "${currentGoal}h per day"

        binding.sliderDailyGoal.addOnChangeListener { _, value, _ ->
            val hours = value.toInt()
            binding.tvDailyGoalValue.text = "${hours}h per day"
            prefs.setDailyGoalHours(hours)
        }
    }

    private fun setupNotificationSection() {
        binding.switchNotifications.isChecked = prefs.areNotificationsEnabled()
        binding.switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            prefs.setNotificationsEnabled(isChecked)
            Snackbar.make(binding.root,
                if (isChecked) "Notifications enabled" else "Notifications disabled",
                Snackbar.LENGTH_SHORT
            ).show()
        }
    }

    private fun setupResetSection() {
        binding.rowResetStats.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Reset Statistics")
                .setMessage("Are you sure you want to delete all usage records? This cannot be undone.")
                .setPositiveButton("Reset") { _, _ ->
                    resetStats()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        binding.rowResetLimits.setOnClickListener {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Reset All Limits")
                .setMessage("Remove all app limits and blocks?")
                .setPositiveButton("Reset") { _, _ ->
                    resetLimits()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun resetStats() {
        val app = requireContext().applicationContext as ScreenTimeApplication
        CoroutineScope(Dispatchers.IO).launch {
            // Delete all usage records
            val today = UsageStatsHelper.getTodayDateString()
            app.usageRecordRepository.deleteOldRecords(today)
        }
        Snackbar.make(binding.root, "Statistics reset!", Snackbar.LENGTH_SHORT).show()
    }

    private fun resetLimits() {
        val app = requireContext().applicationContext as ScreenTimeApplication
        CoroutineScope(Dispatchers.IO).launch {
            app.appLimitRepository.getAllLimitsSync().forEach { limit ->
                app.appLimitRepository.delete(limit)
            }
        }
        Snackbar.make(binding.root, "All limits removed!", Snackbar.LENGTH_SHORT).show()
    }

    private fun setupAboutSection() {
        binding.tvAppVersion.text = "Version 1.0.0"
        binding.rowRateApp.setOnClickListener {
            Snackbar.make(binding.root, "Thank you for using Screen Time!", Snackbar.LENGTH_SHORT).show()
        }
        binding.rowPrivacyPolicy.setOnClickListener {
            Snackbar.make(binding.root, "Privacy policy: We never share your data.", Snackbar.LENGTH_LONG).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
