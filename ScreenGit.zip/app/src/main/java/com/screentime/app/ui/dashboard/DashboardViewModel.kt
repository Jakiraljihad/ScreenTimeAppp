package com.screentime.app.ui.dashboard

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import com.screentime.app.ScreenTimeApplication
import com.screentime.app.data.models.AppUsageInfo
import com.screentime.app.services.UsageStatsHelper
import com.screentime.app.utils.AdviceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ViewModel for Dashboard screen
 * File: app/src/main/java/com/screentime/app/ui/dashboard/DashboardViewModel.kt
 */
class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val usageHelper = UsageStatsHelper(application)
    private val app = application as ScreenTimeApplication

    private val _totalScreenTimeMs = MutableLiveData<Long>(0L)
    val totalScreenTimeMs: LiveData<Long> = _totalScreenTimeMs

    private val _topApps = MutableLiveData<List<AppUsageInfo>>(emptyList())
    val topApps: LiveData<List<AppUsageInfo>> = _topApps

    private val _advice = MutableLiveData<AdviceEngine.Advice>()
    val advice: LiveData<AdviceEngine.Advice> = _advice

    private val _isLoading = MutableLiveData<Boolean>(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _hasPermission = MutableLiveData<Boolean>()
    val hasPermission: LiveData<Boolean> = _hasPermission

    private val _weeklyData = MutableLiveData<Map<String, Long>>(emptyMap())
    val weeklyData: LiveData<Map<String, Long>> = _weeklyData

    init {
        refreshData()
    }

    fun refreshData() {
        viewModelScope.launch {
            _isLoading.value = true
            _hasPermission.value = usageHelper.hasUsageStatsPermission()

            if (usageHelper.hasUsageStatsPermission()) {
                withContext(Dispatchers.IO) {
                    loadUsageData()
                }
            }

            _isLoading.value = false
        }
    }

    private suspend fun loadUsageData() {
        try {
            // Get today's usage
            val todayUsage = usageHelper.getTodayUsage()
            val limits = app.appLimitRepository.getAllLimitsSync()
            val limitMap = limits.associateBy { it.packageName }

            // Merge usage with limit data
            val enrichedUsage = todayUsage.map { usage ->
                val limit = limitMap[usage.packageName]
                usage.copy(
                    limitMinutes = limit?.limitMinutes ?: 0,
                    isBlocked = limit?.isBlocked ?: false
                )
            }

            val totalMs = enrichedUsage.sumOf { it.usageTimeMs }
            val top5 = enrichedUsage.take(5)
            val totalMinutes = totalMs / 60_000L
            val adviceResult = AdviceEngine.getAdvice(totalMinutes)

            withContext(Dispatchers.Main) {
                _totalScreenTimeMs.value = totalMs
                _topApps.value = top5
                _advice.value = adviceResult
            }

            // Weekly data
            val weekly = buildWeeklyData()
            withContext(Dispatchers.Main) {
                _weeklyData.value = weekly
            }
        } catch (e: Exception) {
            Log.e("DashboardVM", "Error loading usage data", e)
        }
    }

    private suspend fun buildWeeklyData(): Map<String, Long> {
        val result = linkedMapOf<String, Long>()
        for (i in 6 downTo 0) {
            val cal = java.util.Calendar.getInstance()
            cal.add(java.util.Calendar.DAY_OF_MONTH, -i)
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            val labelSdf = java.text.SimpleDateFormat("EEE", java.util.Locale.getDefault())
            val dateStr = sdf.format(cal.time)
            val label = labelSdf.format(cal.time)

            cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
            cal.set(java.util.Calendar.MINUTE, 0)
            cal.set(java.util.Calendar.SECOND, 0)
            cal.set(java.util.Calendar.MILLISECOND, 0)
            val start = cal.timeInMillis
            cal.add(java.util.Calendar.DAY_OF_MONTH, 1)
            val end = cal.timeInMillis

            val usage = usageHelper.getUsageForPeriod(start, end).sumOf { it.usageTimeMs }
            result[label] = usage
        }
        return result
    }
}
