package com.screentime.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.screentime.app.data.db.AppDatabase
import com.screentime.app.data.repository.AppLimitRepository
import com.screentime.app.data.repository.UsageRecordRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Application class — initializes app-wide singletons
 * File: app/src/main/java/com/screentime/app/ScreenTimeApplication.kt
 */
class ScreenTimeApplication : Application() {

    // App-level coroutine scope tied to app lifecycle
    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Lazy-init Room database
    val database: AppDatabase by lazy {
        AppDatabase.getDatabase(this)
    }

    // Repositories
    val appLimitRepository: AppLimitRepository by lazy {
        AppLimitRepository(database.appLimitDao())
    }

    val usageRecordRepository: UsageRecordRepository by lazy {
        UsageRecordRepository(database.usageRecordDao())
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    /**
     * Create all notification channels for Android 8+
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            // Monitor service channel
            val monitorChannel = NotificationChannel(
                CHANNEL_MONITOR,
                "App Monitor",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background monitoring service notification"
                setShowBadge(false)
            }

            // Usage alerts channel
            val alertChannel = NotificationChannel(
                CHANNEL_ALERTS,
                "Usage Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts when you approach app limits"
            }

            // Focus mode channel
            val focusChannel = NotificationChannel(
                CHANNEL_FOCUS,
                "Focus Mode",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Focus mode timer notifications"
            }

            notificationManager.createNotificationChannels(
                listOf(monitorChannel, alertChannel, focusChannel)
            )
        }
    }

    companion object {
        const val CHANNEL_MONITOR = "channel_monitor"
        const val CHANNEL_ALERTS = "channel_alerts"
        const val CHANNEL_FOCUS = "channel_focus"
        const val NOTIFICATION_ID_MONITOR = 1001
        const val NOTIFICATION_ID_FOCUS = 1002
    }
}
