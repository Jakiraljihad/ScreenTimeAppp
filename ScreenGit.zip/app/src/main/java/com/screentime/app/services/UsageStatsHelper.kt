package com.screentime.app.services

import android.app.AppOpsManager
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import com.screentime.app.data.models.AppUsageInfo
import java.text.SimpleDateFormat
import java.util.*

/**
 * Helper class to query UsageStatsManager API
 * File: app/src/main/java/com/screentime/app/services/UsageStatsHelper.kt
 *
 * This is the core class that reads phone usage data from Android system.
 */
class UsageStatsHelper(private val context: Context) {

    private val usageStatsManager: UsageStatsManager by lazy {
        context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    }

    private val packageManager: PackageManager = context.packageManager

    /**
     * Check if the app has PACKAGE_USAGE_STATS permission
     */
    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * Get today's app usage list, sorted by usage time descending
     */
    fun getTodayUsage(): List<AppUsageInfo> {
        if (!hasUsageStatsPermission()) return emptyList()

        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)

        val startTime = calendar.timeInMillis
        val endTime = System.currentTimeMillis()

        return getUsageForPeriod(startTime, endTime)
    }

    /**
     * Get usage for a specific day
     * @param date Date string in format "yyyy-MM-dd"
     */
    fun getUsageForDate(date: String): List<AppUsageInfo> {
        if (!hasUsageStatsPermission()) return emptyList()

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val calendar = Calendar.getInstance()
        calendar.time = sdf.parse(date) ?: return emptyList()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)

        val startTime = calendar.timeInMillis
        calendar.add(Calendar.DAY_OF_MONTH, 1)
        val endTime = calendar.timeInMillis

        return getUsageForPeriod(startTime, endTime)
    }

    /**
     * Get usage data for a time period
     */
    fun getUsageForPeriod(startTime: Long, endTime: Long): List<AppUsageInfo> {
        val usageStatsList: Map<String, UsageStats> = usageStatsManager.queryAndAggregateUsageStats(
            startTime, endTime
        )

        return usageStatsList.values
            .filter { stats ->
                stats.totalTimeInForeground > 0 &&
                        !isSystemApp(stats.packageName) &&
                        stats.packageName != context.packageName // exclude our own app
            }
            .map { stats ->
                val appName = getAppName(stats.packageName)
                val icon = try {
                    packageManager.getApplicationIcon(stats.packageName)
                } catch (e: PackageManager.NameNotFoundException) {
                    null
                }
                AppUsageInfo(
                    packageName = stats.packageName,
                    appName = appName,
                    usageTimeMs = stats.totalTimeInForeground,
                    iconDrawable = icon
                )
            }
            .filter { it.usageTimeMs > 60_000 } // filter out < 1 minute
            .sortedByDescending { it.usageTimeMs }
    }

    /**
     * Get total screen time today in milliseconds
     */
    fun getTotalScreenTimeToday(): Long {
        return getTodayUsage().sumOf { it.usageTimeMs }
    }

    /**
     * Get usage for last 7 days — returns map of date -> total usage ms
     */
    fun getWeeklyUsage(): Map<String, Long> {
        if (!hasUsageStatsPermission()) return emptyMap()

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val result = LinkedHashMap<String, Long>()

        val calendar = Calendar.getInstance()

        for (i in 6 downTo 0) {
            val dayCal = Calendar.getInstance()
            dayCal.add(Calendar.DAY_OF_MONTH, -i)
            dayCal.set(Calendar.HOUR_OF_DAY, 0)
            dayCal.set(Calendar.MINUTE, 0)
            dayCal.set(Calendar.SECOND, 0)
            dayCal.set(Calendar.MILLISECOND, 0)

            val startTime = dayCal.timeInMillis
            dayCal.add(Calendar.DAY_OF_MONTH, 1)
            val endTime = dayCal.timeInMillis

            val dayUsage = usageStatsManager.queryAndAggregateUsageStats(startTime, endTime)
                .values
                .filter { !isSystemApp(it.packageName) && it.totalTimeInForeground > 0 }
                .sumOf { it.totalTimeInForeground }

            val dateKey = sdf.format(calendar.apply {
                add(Calendar.DAY_OF_MONTH, -i)
            }.time)
            result[dateKey] = dayUsage

            calendar.add(Calendar.DAY_OF_MONTH, i) // reset
        }

        // Re-build properly
        val resultMap = LinkedHashMap<String, Long>()
        val cal = Calendar.getInstance()
        for (i in 6 downTo 0) {
            cal.time = Date()
            cal.add(Calendar.DAY_OF_MONTH, -i)
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val startTime = cal.timeInMillis
            cal.add(Calendar.DAY_OF_MONTH, 1)
            val endTime = cal.timeInMillis

            val dayTotal = usageStatsManager.queryAndAggregateUsageStats(startTime, endTime)
                .values
                .filter { !isSystemApp(it.packageName) && it.totalTimeInForeground > 0 }
                .sumOf { it.totalTimeInForeground }

            cal.add(Calendar.DAY_OF_MONTH, -1) // go back
            resultMap[sdf.format(cal.time)] = dayTotal
        }

        return resultMap
    }

    /**
     * Get usage for specific package today in minutes
     */
    fun getTodayUsageForPackage(packageName: String): Long {
        return getTodayUsage()
            .find { it.packageName == packageName }
            ?.usageMinutes ?: 0L
    }

    /**
     * Check if a package is a system app
     */
    private fun isSystemApp(packageName: String): Boolean {
        return try {
            val appInfo = packageManager.getApplicationInfo(packageName, 0)
            (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        } catch (e: PackageManager.NameNotFoundException) {
            true // treat unknown as system
        }
    }

    /**
     * Get human-readable app name from package name
     */
    fun getAppName(packageName: String): String {
        return try {
            val appInfo = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            packageName.substringAfterLast(".")
        }
    }

    /**
     * Format milliseconds to human-readable string
     */
    companion object {
        fun formatDuration(ms: Long): String {
            val hours = ms / 3_600_000L
            val minutes = (ms % 3_600_000L) / 60_000L
            val seconds = (ms % 60_000L) / 1_000L
            return when {
                hours > 0 -> "${hours}h ${minutes}m"
                minutes > 0 -> "${minutes}m ${seconds}s"
                else -> "${seconds}s"
            }
        }

        fun formatDurationShort(ms: Long): String {
            val hours = ms / 3_600_000L
            val minutes = (ms % 3_600_000L) / 60_000L
            return when {
                hours > 0 -> "${hours}h ${minutes}m"
                minutes > 0 -> "${minutes}m"
                else -> "< 1m"
            }
        }

        fun getTodayDateString(): String {
            return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        }

        fun getDayLabel(daysAgo: Int): String {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_MONTH, -daysAgo)
            return SimpleDateFormat("EEE", Locale.getDefault()).format(cal.time)
        }
    }
}
