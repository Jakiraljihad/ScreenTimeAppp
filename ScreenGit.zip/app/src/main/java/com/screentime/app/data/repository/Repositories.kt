package com.screentime.app.data.repository

import androidx.lifecycle.LiveData
import com.screentime.app.data.db.AppLimitDao
import com.screentime.app.data.db.UsageRecordDao
import com.screentime.app.data.models.AppLimit
import com.screentime.app.data.models.UsageRecord

/**
 * Repository for app limits — abstracts data layer from ViewModels
 * File: app/src/main/java/com/screentime/app/data/repository/AppLimitRepository.kt
 */
class AppLimitRepository(private val appLimitDao: AppLimitDao) {

    val allLimits: LiveData<List<AppLimit>> = appLimitDao.getAllLimits()

    suspend fun insert(limit: AppLimit) = appLimitDao.insert(limit)

    suspend fun update(limit: AppLimit) = appLimitDao.update(limit)

    suspend fun delete(limit: AppLimit) = appLimitDao.delete(limit)

    suspend fun getLimitForPackage(packageName: String): AppLimit? =
        appLimitDao.getLimitForPackage(packageName)

    fun getLimitForPackageLive(packageName: String) =
        appLimitDao.getLimitForPackageLive(packageName)

    suspend fun getAllLimitsSync(): List<AppLimit> = appLimitDao.getAllLimitsSync()

    suspend fun getBlockedApps(): List<AppLimit> = appLimitDao.getBlockedApps()

    suspend fun setLimitEnabled(packageName: String, enabled: Boolean) =
        appLimitDao.setLimitEnabled(packageName, enabled)

    suspend fun deleteByPackage(packageName: String) =
        appLimitDao.deleteByPackage(packageName)

    /**
     * Check if a given package has exceeded its daily limit
     * @param packageName The app package to check
     * @param usageMinutes Current usage in minutes today
     * @return true if limit exceeded
     */
    suspend fun isLimitExceeded(packageName: String, usageMinutes: Long): Boolean {
        val limit = appLimitDao.getLimitForPackage(packageName) ?: return false
        if (!limit.isEnabled) return false
        if (limit.isBlocked) return true
        return usageMinutes >= limit.limitMinutes
    }
}

/**
 * Repository for usage records
 * File: app/src/main/java/com/screentime/app/data/repository/UsageRecordRepository.kt
 */
class UsageRecordRepository(private val usageRecordDao: UsageRecordDao) {

    fun getUsageForDate(date: String): LiveData<List<UsageRecord>> =
        usageRecordDao.getUsageForDate(date)

    suspend fun getUsageForDateSync(date: String): List<UsageRecord> =
        usageRecordDao.getUsageForDateSync(date)

    fun getUsageForDateRange(startDate: String, endDate: String): LiveData<List<UsageRecord>> =
        usageRecordDao.getUsageForDateRange(startDate, endDate)

    suspend fun getUsageForDateRangeSync(startDate: String, endDate: String): List<UsageRecord> =
        usageRecordDao.getUsageForDateRangeSync(startDate, endDate)

    fun getTotalUsageForDate(date: String): LiveData<Long?> =
        usageRecordDao.getTotalUsageForDate(date)

    suspend fun insertOrUpdate(record: UsageRecord) =
        usageRecordDao.insertOrUpdate(record)

    suspend fun insertAll(records: List<UsageRecord>) =
        usageRecordDao.insertAll(records)

    suspend fun deleteOldRecords(cutoffDate: String) =
        usageRecordDao.deleteOldRecords(cutoffDate)
}
