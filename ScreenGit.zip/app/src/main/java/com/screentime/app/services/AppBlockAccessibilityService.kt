package com.screentime.app.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.screentime.app.ScreenTimeApplication
import com.screentime.app.activities.BlockActivity
import com.screentime.app.utils.PrefsManager
import kotlinx.coroutines.*

/**
 * Accessibility Service — detects when a blocked/limited app opens
 * and immediately redirects user to BlockActivity.
 *
 * File: app/src/main/java/com/screentime/app/services/AppBlockAccessibilityService.kt
 *
 * IMPORTANT: User must manually enable in Android Settings > Accessibility
 */
class AppBlockAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var lastBlockedPackage = ""
    private var lastBlockTime = 0L

    // Cached list of blocked/limited packages for quick lookup
    private var blockedPackages = setOf<String>()
    private var lastCacheUpdate = 0L
    private val CACHE_TTL = 30_000L // 30 seconds cache

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Configure accessibility service info programmatically
        serviceInfo = serviceInfo.apply {
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            notificationTimeout = 100
        }

        // Initial load of blocked packages
        refreshBlockedPackages()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return

        // Ignore our own app and Android system
        if (packageName == applicationContext.packageName) return
        if (packageName.startsWith("com.android.") && !packageName.contains("launcher")) return

        // Refresh cache if stale
        if (System.currentTimeMillis() - lastCacheUpdate > CACHE_TTL) {
            refreshBlockedPackages()
        }

        // Check if this package should be blocked
        if (blockedPackages.contains(packageName)) {
            blockApp(packageName)
            return
        }

        // Check if focus mode is active and this app is in blocked list
        val prefs = PrefsManager(applicationContext)
        if (prefs.isFocusModeActive()) {
            val focusBlockedApps = prefs.getFocusBlockedApps()
            if (focusBlockedApps.contains(packageName)) {
                blockApp(packageName, isFocusMode = true)
                return
            }
        }

        // Check limit exceeded in background
        serviceScope.launch {
            checkUsageLimit(packageName)
        }
    }

    /**
     * Check if the app's usage exceeds its daily limit
     */
    private suspend fun checkUsageLimit(packageName: String) {
        val app = applicationContext as ScreenTimeApplication
        val usageHelper = UsageStatsHelper(applicationContext)
        val limitRepo = app.appLimitRepository

        val limit = limitRepo.getLimitForPackage(packageName) ?: return
        if (!limit.isEnabled) return

        val usageMinutes = usageHelper.getTodayUsageForPackage(packageName)

        if (usageMinutes >= limit.limitMinutes) {
            withContext(Dispatchers.Main) {
                blockApp(packageName, usageMinutes = usageMinutes, limitMinutes = limit.limitMinutes)
            }
        }
    }

    /**
     * Launch BlockActivity to prevent access to the app
     */
    private fun blockApp(
        packageName: String,
        isFocusMode: Boolean = false,
        usageMinutes: Long = 0,
        limitMinutes: Int = 0
    ) {
        // Debounce — don't show block screen too rapidly
        val now = System.currentTimeMillis()
        if (packageName == lastBlockedPackage && now - lastBlockTime < 2000L) return

        lastBlockedPackage = packageName
        lastBlockTime = now

        val appName = UsageStatsHelper(applicationContext).getAppName(packageName)

        val intent = Intent(applicationContext, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(BlockActivity.EXTRA_PACKAGE_NAME, packageName)
            putExtra(BlockActivity.EXTRA_APP_NAME, appName)
            putExtra(BlockActivity.EXTRA_IS_FOCUS_MODE, isFocusMode)
            putExtra(BlockActivity.EXTRA_USAGE_MINUTES, usageMinutes)
            putExtra(BlockActivity.EXTRA_LIMIT_MINUTES, limitMinutes)
        }
        startActivity(intent)
    }

    /**
     * Refresh the cached list of blocked packages from database
     */
    private fun refreshBlockedPackages() {
        serviceScope.launch {
            val app = applicationContext as ScreenTimeApplication
            val limits = app.appLimitRepository.getAllLimitsSync()
            blockedPackages = limits
                .filter { it.isBlocked && it.isEnabled }
                .map { it.packageName }
                .toSet()
            lastCacheUpdate = System.currentTimeMillis()
        }
    }

    override fun onInterrupt() {
        serviceScope.cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
