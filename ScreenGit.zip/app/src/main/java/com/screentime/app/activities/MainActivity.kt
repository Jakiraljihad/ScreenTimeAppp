package com.screentime.app.activities

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.screentime.app.R
import com.screentime.app.databinding.ActivityMainBinding
import com.screentime.app.services.AppMonitorService
import com.screentime.app.utils.PrefsManager

/**
 * Main entry point — hosts all fragments via Navigation Component
 * File: app/src/main/java/com/screentime/app/activities/MainActivity.kt
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check onboarding
        val prefs = PrefsManager(this)
        if (!prefs.isOnboardingComplete()) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish()
            return
        }

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNavigation()
        startMonitorService()
    }

    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        // Top-level destinations (no back button in toolbar)
        val appBarConfig = AppBarConfiguration(
            setOf(
                R.id.dashboardFragment,
                R.id.appUsageFragment,
                R.id.focusFragment,
                R.id.settingsFragment
            )
        )

        setSupportActionBar(binding.toolbar)
        setupActionBarWithNavController(navController, appBarConfig)
        binding.bottomNavigation.setupWithNavController(navController)

        // Update toolbar title on navigation
        navController.addOnDestinationChangedListener { _, destination, _ ->
            binding.toolbar.title = destination.label
        }
    }

    /**
     * Start background monitoring service
     */
    private fun startMonitorService() {
        val serviceIntent = Intent(this, AppMonitorService::class.java).apply {
            action = AppMonitorService.ACTION_START
        }
        startForegroundService(serviceIntent)
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}
