package com.screentime.app.ui.appusage

import android.app.Application
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.Slider
import com.screentime.app.ScreenTimeApplication
import com.screentime.app.adapters.AppUsageAdapter
import com.screentime.app.data.models.AppLimit
import com.screentime.app.data.models.AppUsageInfo
import com.screentime.app.databinding.FragmentAppUsageBinding
import com.screentime.app.databinding.DialogSetLimitBinding
import com.screentime.app.services.UsageStatsHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ===== VIEW MODEL =====

/**
 * ViewModel for App Usage screen
 * File: app/src/main/java/com/screentime/app/ui/appusage/AppUsageViewModel.kt
 */
class AppUsageViewModel(application: Application) : AndroidViewModel(application) {

    private val usageHelper = UsageStatsHelper(application)
    private val app = application as ScreenTimeApplication

    val appUsageList = MutableLiveData<List<AppUsageInfo>>(emptyList())
    val isLoading = MutableLiveData<Boolean>(false)

    init { loadApps() }

    fun loadApps() {
        viewModelScope.launch {
            isLoading.value = true
            withContext(Dispatchers.IO) {
                val usage = usageHelper.getTodayUsage()
                val limits = app.appLimitRepository.getAllLimitsSync()
                val limitMap = limits.associateBy { it.packageName }

                val enriched = usage.map { info ->
                    val limit = limitMap[info.packageName]
                    info.copy(
                        limitMinutes = limit?.limitMinutes ?: 0,
                        isBlocked = limit?.isBlocked ?: false
                    )
                }

                withContext(Dispatchers.Main) {
                    appUsageList.value = enriched
                }
            }
            isLoading.value = false
        }
    }

    fun setLimit(packageName: String, appName: String, limitMinutes: Int, isBlocked: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val limit = AppLimit(
                packageName = packageName,
                appName = appName,
                limitMinutes = limitMinutes,
                isBlocked = isBlocked
            )
            app.appLimitRepository.insert(limit)
            withContext(Dispatchers.Main) { loadApps() }
        }
    }

    fun removeLimit(packageName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            app.appLimitRepository.deleteByPackage(packageName)
            withContext(Dispatchers.Main) { loadApps() }
        }
    }
}

// ===== FRAGMENT =====

/**
 * Fragment showing all app usage with ability to set limits
 * File: app/src/main/java/com/screentime/app/ui/appusage/AppUsageFragment.kt
 */
class AppUsageFragment : Fragment() {

    private var _binding: FragmentAppUsageBinding? = null
    private val binding get() = _binding!!

    private val viewModel: AppUsageViewModel by viewModels()
    private lateinit var adapter: AppUsageAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAppUsageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        observeViewModel()
    }

    override fun onResume() {
        super.onResume()
        viewModel.loadApps()
    }

    private fun setupRecyclerView() {
        adapter = AppUsageAdapter(
            onSetLimit = { appUsage -> showSetLimitDialog(appUsage) },
            onRemoveLimit = { appUsage -> viewModel.removeLimit(appUsage.packageName) }
        )

        binding.rvApps.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@AppUsageFragment.adapter
        }
    }

    private fun observeViewModel() {
        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        }

        viewModel.appUsageList.observe(viewLifecycleOwner) { apps ->
            adapter.submitList(apps)
            binding.tvEmpty.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    /**
     * Dialog for setting app time limit or block
     */
    private fun showSetLimitDialog(app: AppUsageInfo) {
        val dialogBinding = DialogSetLimitBinding.inflate(layoutInflater)

        // Pre-fill existing limit
        if (app.hasLimit) {
            dialogBinding.sliderLimit.value = app.limitMinutes.toFloat().coerceIn(5f, 240f)
            dialogBinding.tvLimitValue.text = "${app.limitMinutes}m"
        }
        dialogBinding.switchBlock.isChecked = app.isBlocked
        dialogBinding.tvAppName.text = app.appName

        dialogBinding.sliderLimit.addOnChangeListener { _, value, _ ->
            dialogBinding.tvLimitValue.text = "${value.toInt()}m"
        }

        // Enable/disable slider based on block switch
        dialogBinding.switchBlock.setOnCheckedChangeListener { _, isChecked ->
            dialogBinding.sliderLimit.isEnabled = !isChecked
            dialogBinding.tvLimitValue.alpha = if (isChecked) 0.5f else 1f
        }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Set Limit for ${app.appName}")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val limitMinutes = dialogBinding.sliderLimit.value.toInt()
                val isBlocked = dialogBinding.switchBlock.isChecked
                viewModel.setLimit(app.packageName, app.appName, limitMinutes, isBlocked)
            }
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Remove Limit") { _, _ ->
                viewModel.removeLimit(app.packageName)
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
