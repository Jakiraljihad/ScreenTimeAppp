package com.screentime.app.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.screentime.app.data.models.AppLimit
import com.screentime.app.data.models.FocusSession
import com.screentime.app.data.models.UsageRecord

/**
 * DAO for usage records
 * File: app/src/main/java/com/screentime/app/data/db/UsageRecordDao.kt
 */
@Dao
interface UsageRecordDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(record: UsageRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(records: List<UsageRecord>)

    @Query("SELECT * FROM usage_records WHERE date = :date ORDER BY usageTimeMs DESC")
    fun getUsageForDate(date: String): LiveData<List<UsageRecord>>

    @Query("SELECT * FROM usage_records WHERE date = :date ORDER BY usageTimeMs DESC")
    suspend fun getUsageForDateSync(date: String): List<UsageRecord>

    @Query("SELECT * FROM usage_records WHERE date >= :startDate AND date <= :endDate ORDER BY date ASC")
    fun getUsageForDateRange(startDate: String, endDate: String): LiveData<List<UsageRecord>>

    @Query("SELECT * FROM usage_records WHERE date >= :startDate AND date <= :endDate ORDER BY date ASC")
    suspend fun getUsageForDateRangeSync(startDate: String, endDate: String): List<UsageRecord>

    @Query("SELECT SUM(usageTimeMs) FROM usage_records WHERE date = :date")
    fun getTotalUsageForDate(date: String): LiveData<Long?>

    @Query("DELETE FROM usage_records WHERE date < :cutoffDate")
    suspend fun deleteOldRecords(cutoffDate: String)

    @Query("SELECT * FROM usage_records WHERE packageName = :packageName AND date = :date LIMIT 1")
    suspend fun getRecordForPackageAndDate(packageName: String, date: String): UsageRecord?
}

/**
 * DAO for app limits
 * File: app/src/main/java/com/screentime/app/data/db/AppLimitDao.kt
 */
@Dao
interface AppLimitDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(limit: AppLimit)

    @Update
    suspend fun update(limit: AppLimit)

    @Delete
    suspend fun delete(limit: AppLimit)

    @Query("SELECT * FROM app_limits ORDER BY appName ASC")
    fun getAllLimits(): LiveData<List<AppLimit>>

    @Query("SELECT * FROM app_limits ORDER BY appName ASC")
    suspend fun getAllLimitsSync(): List<AppLimit>

    @Query("SELECT * FROM app_limits WHERE packageName = :packageName LIMIT 1")
    suspend fun getLimitForPackage(packageName: String): AppLimit?

    @Query("SELECT * FROM app_limits WHERE packageName = :packageName LIMIT 1")
    fun getLimitForPackageLive(packageName: String): LiveData<AppLimit?>

    @Query("SELECT * FROM app_limits WHERE isBlocked = 1")
    suspend fun getBlockedApps(): List<AppLimit>

    @Query("UPDATE app_limits SET isEnabled = :enabled WHERE packageName = :packageName")
    suspend fun setLimitEnabled(packageName: String, enabled: Boolean)

    @Query("DELETE FROM app_limits WHERE packageName = :packageName")
    suspend fun deleteByPackage(packageName: String)
}

/**
 * DAO for focus sessions
 */
@Dao
interface FocusSessionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: FocusSession): Long

    @Update
    suspend fun update(session: FocusSession)

    @Query("SELECT * FROM focus_sessions WHERE date = :date ORDER BY startTime DESC")
    fun getSessionsForDate(date: String): LiveData<List<FocusSession>>

    @Query("SELECT COUNT(*) FROM focus_sessions WHERE isCompleted = 1 AND date = :date")
    fun getCompletedSessionsForDate(date: String): LiveData<Int>

    @Query("SELECT * FROM focus_sessions WHERE isCompleted = 0 ORDER BY startTime DESC LIMIT 1")
    suspend fun getActiveSession(): FocusSession?
}
