package com.screentime.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.screentime.app.services.AppMonitorService

/**
 * Boot receiver — restarts monitor service after device reboot
 * File: app/src/main/java/com/screentime/app/receivers/BootReceiver.kt
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val serviceIntent = Intent(context, AppMonitorService::class.java).apply {
                action = AppMonitorService.ACTION_START
            }
            context.startForegroundService(serviceIntent)
        }
    }
}
