package com.screentime.app.activities

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.view.WindowManager
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.screentime.app.R
import com.screentime.app.databinding.ActivityBlockBinding
import com.screentime.app.utils.AdviceEngine

/**
 * Block screen — shown when a limited/blocked app is opened
 * File: app/src/main/java/com/screentime/app/activities/BlockActivity.kt
 *
 * This activity appears over the blocked app and prevents access.
 */
class BlockActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBlockBinding
    private var cooldownTimer: CountDownTimer? = null

    // Cooldown before user can dismiss (20 seconds makes it hard to bypass)
    private val COOLDOWN_SECONDS = 20L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show on lock screen
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )

        binding = ActivityBlockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val packageName = intent.getStringExtra(EXTRA_PACKAGE_NAME) ?: ""
        val appName = intent.getStringExtra(EXTRA_APP_NAME) ?: "This App"
        val isFocusMode = intent.getBooleanExtra(EXTRA_IS_FOCUS_MODE, false)
        val usageMinutes = intent.getLongExtra(EXTRA_USAGE_MINUTES, 0L)
        val limitMinutes = intent.getIntExtra(EXTRA_LIMIT_MINUTES, 0)

        setupUI(appName, isFocusMode, usageMinutes, limitMinutes)
        startCooldown()
        playEntranceAnimation()
    }

    private fun setupUI(
        appName: String,
        isFocusMode: Boolean,
        usageMinutes: Long,
        limitMinutes: Int
    ) {
        with(binding) {
            if (isFocusMode) {
                blockEmoji.text = "🎯"
                blockTitle.text = "Focus Mode Active"
                blockSubtitle.text = "$appName is blocked during your focus session."
                blockMessage.text = "Stay focused! You're doing great.\nComplete your session to unlock apps."
                blockStats.visibility = View.GONE
            } else {
                blockEmoji.text = "⛔"
                blockTitle.text = "Daily Limit Reached"
                blockSubtitle.text = "You've hit your $appName limit for today."
                blockMessage.text = "\"Daily limit reached.\nTake a break — you deserve it.\""

                if (limitMinutes > 0) {
                    blockStats.visibility = View.VISIBLE
                    blockStatsText.text = "Used: ${usageMinutes}m / Limit: ${limitMinutes}m"
                }
            }

            // Random wellbeing tip
            val tip = AdviceEngine.wellbeingTips.random()
            blockTip.text = tip

            // Back to home button
            btnGoHome.setOnClickListener {
                goToHome()
            }

            // Dismiss button (enabled after cooldown)
            btnDismiss.isEnabled = false
            btnDismiss.text = "Wait ${COOLDOWN_SECONDS}s..."
            btnDismiss.setOnClickListener {
                finish()
            }
        }
    }

    /**
     * Countdown before allowing dismiss
     */
    private fun startCooldown() {
        cooldownTimer = object : CountDownTimer(COOLDOWN_SECONDS * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val secsLeft = millisUntilFinished / 1000L + 1
                binding.btnDismiss.text = "Wait ${secsLeft}s..."
                binding.cooldownProgress.progress =
                    ((COOLDOWN_SECONDS - secsLeft).toFloat() / COOLDOWN_SECONDS * 100).toInt()
            }

            override fun onFinish() {
                binding.btnDismiss.isEnabled = true
                binding.btnDismiss.text = "Dismiss (Not Recommended)"
                binding.cooldownProgress.progress = 100
            }
        }.start()
    }

    private fun playEntranceAnimation() {
        val slideIn = AnimationUtils.loadAnimation(this, R.anim.slide_up)
        binding.blockCard.startAnimation(slideIn)
    }

    /**
     * Navigate to device home screen
     */
    private fun goToHome() {
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
        finish()
    }

    override fun onBackPressed() {
        // Override back press — redirect to home instead
        goToHome()
    }

    override fun onDestroy() {
        super.onDestroy()
        cooldownTimer?.cancel()
    }

    companion object {
        const val EXTRA_PACKAGE_NAME = "extra_package_name"
        const val EXTRA_APP_NAME = "extra_app_name"
        const val EXTRA_IS_FOCUS_MODE = "extra_is_focus_mode"
        const val EXTRA_USAGE_MINUTES = "extra_usage_minutes"
        const val EXTRA_LIMIT_MINUTES = "extra_limit_minutes"
    }
}
