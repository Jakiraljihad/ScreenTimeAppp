package com.screentime.app.utils

/**
 * Generates usage advice based on screen time
 * File: app/src/main/java/com/screentime/app/utils/AdviceEngine.kt
 */
object AdviceEngine {

    enum class UsageLevel { EXCELLENT, GOOD, MODERATE, HIGH, EXCESSIVE }

    data class Advice(
        val level: UsageLevel,
        val emoji: String,
        val title: String,
        val message: String,
        val tip: String
    )

    /**
     * Get advice based on total daily screen time in minutes
     */
    fun getAdvice(totalMinutes: Long, dailyGoalHours: Int = 3): Advice {
        val goalMinutes = dailyGoalHours * 60L

        return when {
            totalMinutes < 60 -> Advice(
                level = UsageLevel.EXCELLENT,
                emoji = "🌟",
                title = "Excellent Digital Balance!",
                message = "You've used your phone less than 1 hour today. That's amazing!",
                tip = "Keep up this healthy habit. Your eyes and mind thank you!"
            )
            totalMinutes < goalMinutes * 0.5 -> Advice(
                level = UsageLevel.GOOD,
                emoji = "✅",
                title = "Great Job!",
                message = "You're well within your daily goal. You're in control.",
                tip = "Try spending the saved time on a hobby or physical activity."
            )
            totalMinutes < goalMinutes -> Advice(
                level = UsageLevel.MODERATE,
                emoji = "👍",
                title = "On Track",
                message = "You've used ${formatMinutes(totalMinutes)} today.",
                tip = "You're approaching your goal. Consider taking a break soon."
            )
            totalMinutes < goalMinutes * 1.5 -> Advice(
                level = UsageLevel.HIGH,
                emoji = "⚠️",
                title = "Over Your Goal",
                message = "You've used your phone ${formatMinutes(totalMinutes)} today — above your goal.",
                tip = "Try resting your eyes. Look at something 20 feet away for 20 seconds."
            )
            totalMinutes < 360 -> Advice(
                level = UsageLevel.HIGH,
                emoji = "😮",
                title = "High Screen Time",
                message = "You've used your phone ${formatMinutes(totalMinutes)} today.",
                tip = "Take a long break. Try a 15-minute walk without your phone."
            )
            else -> Advice(
                level = UsageLevel.EXCESSIVE,
                emoji = "🔴",
                title = "Too Much Screen Time",
                message = "You've been on your phone ${formatMinutes(totalMinutes)} today. Time for a real break!",
                tip = "Put your phone away for at least 30 minutes. Your sleep and health will improve."
            )
        }
    }

    private fun formatMinutes(minutes: Long): String {
        val hours = minutes / 60
        val mins = minutes % 60
        return when {
            hours > 0 -> "${hours}h ${mins}m"
            else -> "${mins}m"
        }
    }

    /**
     * Tips list — shown on dashboard
     */
    val wellbeingTips = listOf(
        "📱 Try putting your phone face-down during meals.",
        "🌙 Avoid screens 1 hour before bedtime for better sleep.",
        "👁️ Use the 20-20-20 rule: every 20 minutes, look 20 feet away for 20 seconds.",
        "🚶 Take a 5-minute walk every hour instead of scrolling.",
        "🔕 Turn on Do Not Disturb during focused work time.",
        "📚 Replace 15 minutes of social media with reading each day.",
        "🧘 Start your morning without checking your phone for the first 30 minutes.",
        "💬 Replace online chats with real face-to-face conversations.",
        "🎯 Set a specific time to check social media instead of constantly checking.",
        "🌿 Notice when you're reaching for your phone out of boredom vs. need.",
        "⏰ Use app timers to be mindful of how long you spend on each app.",
        "🏃 Physical exercise is proven to reduce phone dependency.",
        "📵 Designate phone-free zones in your home (bedroom, dining room).",
        "🎨 Rediscover offline hobbies: drawing, cooking, music, or gardening.",
        "🤝 Be present — put your phone away when with friends and family."
    )
}
