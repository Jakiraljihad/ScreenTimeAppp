package com.screentime.app.utils

import android.content.Context
import android.content.SharedPreferences

/**
 * SharedPreferences wrapper for simple key-value storage
 * File: app/src/main/java/com/screentime/app/utils/PrefsManager.kt
 */
class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // ---- Focus Mode ----

    fun isFocusModeActive(): Boolean = prefs.getBoolean(KEY_FOCUS_ACTIVE, false)

    fun setFocusModeActive(active: Boolean) = prefs.edit().putBoolean(KEY_FOCUS_ACTIVE, active).apply()

    fun getFocusEndTime(): Long = prefs.getLong(KEY_FOCUS_END_TIME, 0L)

    fun setFocusEndTime(time: Long) = prefs.edit().putLong(KEY_FOCUS_END_TIME, time).apply()

    fun getFocusDurationMinutes(): Int = prefs.getInt(KEY_FOCUS_DURATION, 25)

    fun setFocusDurationMinutes(minutes: Int) = prefs.edit().putInt(KEY_FOCUS_DURATION, minutes).apply()

    fun getFocusBlockedApps(): Set<String> = prefs.getStringSet(KEY_FOCUS_BLOCKED_APPS, emptySet()) ?: emptySet()

    fun setFocusBlockedApps(apps: Set<String>) = prefs.edit().putStringSet(KEY_FOCUS_BLOCKED_APPS, apps).apply()

    // ---- Onboarding ----

    fun isOnboardingComplete(): Boolean = prefs.getBoolean(KEY_ONBOARDING_DONE, false)

    fun setOnboardingComplete(done: Boolean) = prefs.edit().putBoolean(KEY_ONBOARDING_DONE, done).apply()

    // ---- Notifications ----

    fun areNotificationsEnabled(): Boolean = prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true)

    fun setNotificationsEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, enabled).apply()

    // ---- Daily Goal ----

    fun getDailyGoalHours(): Int = prefs.getInt(KEY_DAILY_GOAL_HOURS, 3)

    fun setDailyGoalHours(hours: Int) = prefs.edit().putInt(KEY_DAILY_GOAL_HOURS, hours).apply()

    // ---- Stats Reset ----

    fun getLastStatsResetDate(): String = prefs.getString(KEY_LAST_RESET, "") ?: ""

    fun setLastStatsResetDate(date: String) = prefs.edit().putString(KEY_LAST_RESET, date).apply()

    // ---- Generic ----

    fun getLong(key: String, default: Long): Long = prefs.getLong(key, default)

    fun putLong(key: String, value: Long) = prefs.edit().putLong(key, value).apply()

    fun getBoolean(key: String, default: Boolean): Boolean = prefs.getBoolean(key, default)

    fun putBoolean(key: String, value: Boolean) = prefs.edit().putBoolean(key, value).apply()

    companion object {
        private const val PREFS_NAME = "screen_time_prefs"
        const val KEY_FOCUS_ACTIVE = "focus_mode_active"
        const val KEY_FOCUS_END_TIME = "focus_end_time"
        const val KEY_FOCUS_DURATION = "focus_duration_minutes"
        const val KEY_FOCUS_BLOCKED_APPS = "focus_blocked_apps"
        const val KEY_ONBOARDING_DONE = "onboarding_complete"
        const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        const val KEY_DAILY_GOAL_HOURS = "daily_goal_hours"
        const val KEY_LAST_RESET = "last_stats_reset"
    }
}
