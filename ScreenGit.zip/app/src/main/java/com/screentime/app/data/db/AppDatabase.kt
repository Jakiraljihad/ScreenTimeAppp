package com.screentime.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.screentime.app.data.models.AppLimit
import com.screentime.app.data.models.FocusSession
import com.screentime.app.data.models.UsageRecord

/**
 * Room Database — single source of truth for local data
 * File: app/src/main/java/com/screentime/app/data/db/AppDatabase.kt
 */
@Database(
    entities = [UsageRecord::class, AppLimit::class, FocusSession::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun usageRecordDao(): UsageRecordDao
    abstract fun appLimitDao(): AppLimitDao
    abstract fun focusSessionDao(): FocusSessionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "screen_time_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
